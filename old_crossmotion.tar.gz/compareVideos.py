

import processOutputs
import ReadOutput
import os,os.path
import sys
import numpy
import matplotlib.pyplot as plt
from sklearn.metrics.pairwise import cosine_similarity
import math

from numpy import dot
from numpy.linalg import norm
from scipy import spatial
#array of directories
def compareVideos(args):

	planes = []
	vidMatrix = []
	angleMatrix = []


	for i in args:
		print i
		[output,vidAngle] = ReadOutput.readOutputs(i)
		vidMatrix.append(output)
		plane=processOutputs.getPlane(output)
		planes.append(plane)
		angleMatrix.append(vidAngle)
		normAngles = [] #result of the polyfit for the angle vectors

	
	if(len(set(planes))>1):
		print("Videos not in the same plane, makes no sense to compare them!!!\n")
		sys.exit(1)	
	
	#print set of planes (which is the plane)
	

	


	for j in vidMatrix:
	
		if(plane=="right" or plane =="front" or plane=="back"):




			[x,y,t] = processOutputs.extractEquationsNorm(j['rKnee'])
		

			[x,y,t] = processOutputs.extractEquationsNorm(j['rHip'])



		else: # left plane


			[x,y,t] = processOutputs.extractEquationsNorm(j['lKnee'])
			
			[x,y,t] = processOutputs.extractEquationsNorm(j['lHip'])


	for i in angleMatrix:

		if(plane=="right" or plane =="front" or plane=="back"):



			theta = [processOutputs.normalizeAngles(i['rKneeHip']),processOutputs.normalizeAngles(i['rKneeAnkle']),processOutputs.normalizeAngles(i['rHipAnkle'])] 

			title = 'right side'
		else: # left plane

			theta = [processOutputs.normalizeAngles(i['lKneeHip']),processOutputs.normalizeAngles(i['lKneeAnkle']),processOutputs.normalizeAngles(i['lHipAnkle'])] 
			title = 'left side'

		normAngles.append(theta)



	plotAngles(normAngles,title)
	compareAngles(normAngles)


def compareAngles(angleMatrix):

	for i,elem in enumerate(angleMatrix):
		for j in xrange(i+1,len(angleMatrix)):
			print('Similarity between videos ' + str(i) + 'and' + str(j) + ':	' + str(getSimilarity(angleMatrix[i],angleMatrix[j])))
			#print('\nCorrelation coefficient between videos ' + str(i) + 'and' + str(j) + ':	' + str(numpy.corrcoef(angleMatrix[i],angleMatrix[j])))



def plotAngles(angles,title):

	
	t = xrange(len(angles[0][1]))
	print(len(angles[0][1]))
	plt.figure(1)
	plt.title(title)
	for i,theta in enumerate(angles):
		plt.plot(t,theta[1],label='video'+str(i))
	plt.legend()
	plt.show()
	plt.clf()






#the input is two numeric vectors to get the similarity
def getSimilarity(a,b):

	#print(len(x1))
	#print(len(x2))
	#if(len(x1) > len (x2)):
	#	a=numpy.pad(x2,(0,len(x1)-len(x2)),'constant') 
	#	b=x1
	#else:
	#	a=x2
	#	b=numpy.pad(x1,(0,len(x2)-len(x1)),'constant') 
	
	a = numpy.array(a).reshape(1,-1)
	b = numpy.array(b).reshape(1,-1)
	#cosSim = dot(a, b)/(norm(a)*norm(b)) 

	cosSim=cosine_similarity(a,b)
	#cosSim = 1 - spatial.distance.cosine(a, b)



	return cosSim


def getSimilarityMatrix(keypointMatrix):


	for i in xrange(len(keypointMatrix)):
		if(i<len(keypointMatrix)):
			for x in xrange(i+1,len(keypointMatrix)):
				print('Vertical similarity between videos '+str(i+1)+' and '+str(x+1)+':'+str(getSimilarity(keypointMatrix[i][1],keypointMatrix[x][1])))
				print('Horizontal similarity between videos '+str(i+1)+' and '+str(x+1)+':'+str(getSimilarity(keypointMatrix[i][0],keypointMatrix[x][0])))
				correlationY=numpy.correlate(keypointMatrix[i][1],keypointMatrix[x][1])
				print('correlation matrix')
				print(correlationY)

#inputs for this function are the keypoint positions (array of nVideos size in format [x,y,t]) of a certain joint and the title for the graph
def plotMovements(keypoint,keypointName):

	plt.figure(1)
	plt.title(keypointName+'Y positions')
	#first plot y position
	for idx,i in enumerate(keypoint):
		plt.plot(i[2],i[1],label='video'+str(idx))
	plt.legend()
	plt.show()	
	plt.clf()


	#plot x position
	plt.title(keypointName+'X positions')
	for idx,i in enumerate(keypoint):
		plt.plot(i[2],i[0],label='video'+str(idx))
	plt.legend()
	plt.show()	




	





if __name__ == "__main__":
	
	print(sys.argv)
	compareVideos([sys.argv[x] for x,value in enumerate(sys.argv) if x > 0 ])